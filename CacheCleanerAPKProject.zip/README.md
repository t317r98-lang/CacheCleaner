# Cache Cleaner APK Project

## Build
Open this project in Android Studio.

1. Let Android Studio sync Gradle.
2. Select the `app` configuration.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The generated debug APK will normally be:
`app/build/outputs/apk/debug/app-debug.apk`

## Important Android limitation
A normal third-party Android application cannot silently clear the cache of every other installed app. Android's sandbox prevents this.

This project therefore opens the system storage settings and can clear its own cache.

For a true device-wide cleaner, an ADB, root, or managed-device approach would be required.

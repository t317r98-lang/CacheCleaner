package com.example.cachecleaner

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Cache Cleaner"
            textSize = 28f
            setPadding(0, 0, 0, 24)
        }

        val info = TextView(this).apply {
            text = "通常のAndroidアプリでは、他のアプリのキャッシュを直接削除できません。\n\nこのアプリからAndroidのストレージ設定を開けます。また、このアプリ自身のキャッシュは削除できます。"
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }

        val storage = Button(this).apply {
            text = "ストレージ設定を開く"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
            }
        }

        val ownCache = Button(this).apply {
            text = "このアプリのキャッシュを削除"
            setOnClickListener {
                cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(storage)
        root.addView(ownCache)

        setContentView(root)
    }
}
